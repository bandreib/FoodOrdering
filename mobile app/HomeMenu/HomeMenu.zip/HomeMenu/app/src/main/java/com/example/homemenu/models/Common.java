package com.example.homemenu.models;

import java.util.ArrayList;

public class Common {
    public static User currentUser;
    public static ArrayList<Restaurant> currentRestaurant;
}
