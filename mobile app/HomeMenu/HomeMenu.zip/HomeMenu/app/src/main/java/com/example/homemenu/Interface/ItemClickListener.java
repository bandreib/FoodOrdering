package com.example.homemenu.Interface;

public interface ItemClickListener {
    void onClick(int position);
}
