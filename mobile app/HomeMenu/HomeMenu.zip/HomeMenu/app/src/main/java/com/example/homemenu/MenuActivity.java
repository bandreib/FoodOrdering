package com.example.homemenu;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.homemenu.adapters.HttpHandler;
import com.example.homemenu.adapters.MenuAdapter;
import com.example.homemenu.adapters.RestaurantAdapter;
import com.example.homemenu.models.Common;
import com.example.homemenu.models.Meniu;
import com.example.homemenu.models.Restaurant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {
    TextView txt_rest_nume;
    private ArrayList<Meniu> meniuList;
    static private ArrayList<Restaurant> mRestaurantCollection;
    private static final String TAG = "MenuActivity";
    private RecyclerView mMenuRecyclerView;
    private MenuAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        meniuList = new ArrayList<>();
        Intent intent = getIntent();
        int value = intent.getIntExtra("position",0);
        meniuList = Common.currentRestaurant.get(value).getMeniuList();
        Log.d(TAG, "onClick: clicked."+value);
        //Toast.makeText(this, ""+meniuList.size(), Toast.LENGTH_SHORT).show();
        init();
    }

    private void init(){
        mMenuRecyclerView = (RecyclerView)findViewById(R.id.recycler_item);
        mMenuRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mMenuRecyclerView.setHasFixedSize(true);
        mAdapter = new MenuAdapter(meniuList,this);
        mMenuRecyclerView.setAdapter(mAdapter);

    }



}
